using PLANAZO.Modelos;

namespace PLANAZO.Servicios;

public sealed class GestorReservas
{
    private readonly List<Evento> _eventos = new();
    private readonly List<Usuario> _usuarios = new();
    private readonly List<Reserva> _reservas = new();
    private int _siguienteUsuarioId = 1;
    private int _siguienteReservaId = 1;

    public void RegistrarEvento(Evento evento)
    {
        ArgumentNullException.ThrowIfNull(evento);
        if (_eventos.Any(e => e.Id == evento.Id))
            throw new InvalidOperationException($"Ya existe un evento con identificador {evento.Id}.");
        _eventos.Add(evento);
    }

    public IReadOnlyList<Evento> ObtenerEventos() => _eventos.AsReadOnly();

    public Evento ConsultarEvento(int id) =>
        _eventos.FirstOrDefault(e => e.Id == id)
        ?? throw new KeyNotFoundException($"No existe un evento con identificador {id}.");

    public Usuario ObtenerOCrearUsuario(string nombre)
    {
        if (string.IsNullOrWhiteSpace(nombre))
            throw new ArgumentException("El nombre de la persona es obligatorio.", nameof(nombre));

        Usuario? existente = _usuarios.FirstOrDefault(u =>
            string.Equals(u.Nombre, nombre.Trim(), StringComparison.OrdinalIgnoreCase));

        if (existente is not null) return existente;

        var usuario = new Usuario(_siguienteUsuarioId++, nombre);
        _usuarios.Add(usuario);
        return usuario;
    }

    public Reserva CrearReserva(int usuarioId, int eventoId, int cantidad)
    {
        if (cantidad <= 0)
            throw new ArgumentOutOfRangeException(nameof(cantidad), "La cantidad de entradas debe ser mayor que cero.");

        Usuario usuario = _usuarios.FirstOrDefault(u => u.Id == usuarioId)
            ?? throw new KeyNotFoundException($"No existe un usuario con identificador {usuarioId}.");
        Evento evento = ConsultarEvento(eventoId);

        // Primero se valida el cupo; luego se crea la reserva y se descuenta la capacidad.
        if (cantidad > evento.CuposDisponibles)
            throw new InvalidOperationException($"No hay suficientes cupos. Disponibles: {evento.CuposDisponibles}.");

        var reserva = new Reserva(_siguienteReservaId, usuario, evento, cantidad);
        evento.ReservarCupos(cantidad);
        _reservas.Add(reserva);
        _siguienteReservaId++;
        return reserva;
    }

    public IReadOnlyList<Reserva> ObtenerReservas() => _reservas.AsReadOnly();

    public Reserva ConsultarReserva(int id) =>
        _reservas.FirstOrDefault(r => r.Id == id)
        ?? throw new KeyNotFoundException($"No existe una reserva con identificador {id}.");

    public void CancelarReserva(int id)
    {
        Reserva reserva = ConsultarReserva(id);
        if (reserva.Estado == EstadoReserva.Cancelada)
            throw new InvalidOperationException("Esta reserva ya fue cancelada.");

        reserva.Evento.DevolverCupos(reserva.CantidadEntradas);
        reserva.MarcarCancelada();
    }

    public ResumenReservas ObtenerResumen()
    {
        List<Reserva> activas = _reservas.Where(r => r.Estado == EstadoReserva.Activa).ToList();
        return new ResumenReservas(
            activas.Count,
            activas.Sum(r => r.CantidadEntradas),
            activas.Sum(r => r.ValorTotal));
    }

    public IReadOnlyList<Reserva> ObtenerReservasPorUsuario(string nombre)
    {
        if (string.IsNullOrWhiteSpace(nombre)) return Array.Empty<Reserva>();
        return _reservas
            .Where(r => string.Equals(r.NombrePersona, nombre.Trim(), StringComparison.OrdinalIgnoreCase))
            .ToList()
            .AsReadOnly();
    }
}


public sealed record ResumenReservas(int ReservasActivas, int EntradasReservadas, decimal ValorTotal);
