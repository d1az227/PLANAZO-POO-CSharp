namespace PLANAZO.Modelos;

public abstract class Evento
{
    public int Id { get; }
    public string Nombre { get; private set; }
    public DateTime Fecha { get; private set; }
    public decimal PrecioBase { get; private set; }
    public int CapacidadMaxima { get; }
    public int CuposDisponibles { get; private set; }
    public abstract string Tipo { get; }

    protected Evento(int id, string nombre, DateTime fecha, decimal precioBase, int capacidadMaxima)
    {
        if (id <= 0) throw new ArgumentOutOfRangeException(nameof(id), "El identificador debe ser positivo.");
        if (string.IsNullOrWhiteSpace(nombre)) throw new ArgumentException("El nombre es obligatorio.", nameof(nombre));
        if (precioBase < 0) throw new ArgumentOutOfRangeException(nameof(precioBase), "El precio no puede ser negativo.");
        if (capacidadMaxima <= 0) throw new ArgumentOutOfRangeException(nameof(capacidadMaxima), "La capacidad debe ser mayor que cero.");

        Id = id;
        Nombre = nombre.Trim();
        Fecha = fecha;
        PrecioBase = precioBase;
        CapacidadMaxima = capacidadMaxima;
        CuposDisponibles = capacidadMaxima;
    }

    public abstract decimal CalcularPrecioFinal();

    public void ReservarCupos(int cantidad)
    {
        if (cantidad <= 0) throw new ArgumentOutOfRangeException(nameof(cantidad), "La cantidad debe ser mayor que cero.");
        if (cantidad > CuposDisponibles) throw new InvalidOperationException($"No hay suficientes cupos. Disponibles: {CuposDisponibles}.");
        CuposDisponibles -= cantidad;
    }

    public void DevolverCupos(int cantidad)
    {
        if (cantidad <= 0) throw new ArgumentOutOfRangeException(nameof(cantidad), "La cantidad debe ser mayor que cero.");
        if (CuposDisponibles + cantidad > CapacidadMaxima)
            throw new InvalidOperationException("La devolución superaría la capacidad máxima del evento.");
        CuposDisponibles += cantidad;
    }

    public override string ToString() =>
        $"[{Id}] {Nombre} | {Tipo} | {Fecha:dd/MM/yyyy} | Precio: {CalcularPrecioFinal():C} | Cupos: {CuposDisponibles}/{CapacidadMaxima}";
}
