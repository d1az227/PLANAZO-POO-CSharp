namespace PLANAZO.Modelos;

public enum EstadoReserva
{
    Activa,
    Cancelada
}

public sealed class Reserva
{
    public int Id { get; }
    public Usuario Usuario { get; }
    public string NombrePersona => Usuario.Nombre;
    public Evento Evento { get; }
    public int CantidadEntradas { get; }
    public decimal ValorTotal { get; }
    public EstadoReserva Estado { get; private set; }

    public Reserva(int id, Usuario usuario, Evento evento, int cantidadEntradas)
    {
        if (id <= 0) throw new ArgumentOutOfRangeException(nameof(id));
        Usuario = usuario ?? throw new ArgumentNullException(nameof(usuario));
        Evento = evento ?? throw new ArgumentNullException(nameof(evento));
        if (cantidadEntradas <= 0)
            throw new ArgumentOutOfRangeException(nameof(cantidadEntradas), "La cantidad de entradas debe ser mayor que cero.");

        Id = id;
        CantidadEntradas = cantidadEntradas;
        ValorTotal = evento.CalcularPrecioFinal() * cantidadEntradas;
        Estado = EstadoReserva.Activa;
    }

    public void MarcarCancelada()
    {
        if (Estado == EstadoReserva.Cancelada)
            throw new InvalidOperationException("Esta reserva ya fue cancelada.");
        Estado = EstadoReserva.Cancelada;
    }

    public override string ToString() =>
        $"Reserva #{Id} | {NombrePersona} | {Evento.Nombre} | Entradas: {CantidadEntradas} | Total: {ValorTotal:C} | Estado: {Estado}";
}


public sealed class Usuario
{
    public int Id { get; }
    public string Nombre { get; private set; }

    public Usuario(int id, string nombre)
    {
        if (id <= 0) throw new ArgumentOutOfRangeException(nameof(id));
        if (string.IsNullOrWhiteSpace(nombre)) throw new ArgumentException("El nombre es obligatorio.", nameof(nombre));
        Id = id;
        Nombre = nombre.Trim();
    }

    public override string ToString() => $"[{Id}] {Nombre}";
}
