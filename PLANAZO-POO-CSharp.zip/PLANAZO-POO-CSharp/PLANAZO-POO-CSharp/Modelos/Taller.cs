namespace PLANAZO.Modelos;

public sealed class Taller : Evento
{
    public override string Tipo => "Taller";

    public Taller(int id, string nombre, DateTime fecha, decimal precioBase, int capacidadMaxima)
        : base(id, nombre, fecha, precioBase, capacidadMaxima) { }

    public override decimal CalcularPrecioFinal() => decimal.Round(PrecioBase * 0.90m, 2, MidpointRounding.AwayFromZero);
}
