# PLANAZO — Sistema de gestión de eventos y reservas

**Estudiante:** Elkin Elias Diaz 
**Asignatura:** Programación Orientada a Objetos  
**Lenguaje:** C#  
**Plataforma:** .NET 8

## 1. Descripción

PLANAZO es una aplicación de consola para consultar eventos, registrar personas, crear y cancelar reservas, consultar las reservas realizadas y ver un resumen de las entradas reservadas.

## 2. Funcionalidades

- Listar y consultar eventos.
- Gestionar eventos de cine, conciertos y talleres.
- Calcular el precio final según el tipo de evento.
- Registrar personas al realizar una reserva.
- Crear, consultar y cancelar reservas.
- Comprobar los cupos disponibles y devolverlos al cancelar una reserva.
- Consultar reservas por persona y ver un resumen de reservas activas.
- Validar entradas incorrectas del menú.

## 3. Estructura del proyecto

```text
PLANAZO-POO-CSharp/
├── Program.cs
├── PLANAZO-POO-CSharp.csproj
├── Modelos/
│   ├── Evento.cs
│   ├── Cine.cs
│   ├── Concierto.cs
│   ├── Taller.cs
│   └── Reserva.cs
├── Servicios/
│   └── GestorReservas.cs
├── Capturas/
├── README.md
└── .gitignore
```

El archivo `.csproj` se incluye porque es necesario para que .NET reconozca y ejecute el proyecto.

## 4. Clases y relaciones

- **`Evento`**: clase abstracta que define los datos comunes: identificador, nombre, fecha, precio base, capacidad máxima y cupos disponibles. También declara el cálculo del precio final y controla la reserva o devolución de cupos.
- **`Cine`**: hereda de `Evento` y mantiene el precio base.
- **`Concierto`**: hereda de `Evento` y aumenta el precio base un 15 %.
- **`Taller`**: hereda de `Evento` y aplica un descuento del 10 % al precio base.
- **`Reserva`**: representa una reserva y relaciona una persona con un evento, indicando la cantidad de entradas, el valor total y el estado. En este mismo archivo se define la clase `Usuario`, que representa a la persona que reserva.
- **`GestorReservas`**: administra los eventos, las personas y las reservas; valida cupos, crea y cancela reservas, consulta reservas y calcula el resumen. En este archivo se define el registro `ResumenReservas`, que contiene los totales del resumen.
- **`Program.cs`**: presenta el menú y conecta las opciones del usuario con los servicios.

Las clases `Cine`, `Concierto` y `Taller` heredan de `Evento`. Una `Reserva` contiene una referencia a un `Usuario` y a un `Evento`. `GestorReservas` coordina las operaciones del sistema.

## 5. Conceptos de POO implementados

- **Encapsulamiento:** las clases controlan el acceso a sus datos mediante propiedades públicas de solo lectura o con `private set`, y validan los datos al crear objetos o modificar cupos.
- **Abstracción:** `Evento` es una clase abstracta que representa las características comunes de un evento y declara el método abstracto `CalcularPrecioFinal()`.
- **Herencia:** `Cine`, `Concierto` y `Taller` heredan de `Evento`, reutilizando sus propiedades y operaciones comunes.
- **Polimorfismo:** cada tipo concreto sobrescribe `CalcularPrecioFinal()`. El sistema puede tratar los distintos tipos como objetos `Evento` y obtener el precio adecuado según el tipo real.

## 6. Reglas de precios

- **Cine:** precio final = precio base.
- **Concierto:** precio final = precio base × 1,15.
- **Taller:** precio final = precio base × 0,90.

El valor total de una reserva se calcula multiplicando el precio final del evento por la cantidad de entradas.

## 7. Ejecución

Con .NET 8 instalado, abre una terminal en la carpeta que contiene `PLANAZO-POO-CSharp.csproj` y ejecuta:

```bash
dotnet run
```

## 8. Capturas de pantalla y pruebas

Guarda en la carpeta `Capturas/` imágenes reales de las pruebas realizadas. Se recomienda incluir:

1. Menú principal.
2. Listado de eventos.
3. Detalle de un evento de cine, concierto y taller para comprobar sus precios.
4. Creación de una reserva.
5. Consulta y cancelación de una reserva.
6. Resumen de reservas.
7. Entrada de una opción inexistente y el mensaje de validación.

Las capturas deben añadirse después de ejecutar las pruebas; no se incluyen imágenes ficticias.

## 9. Conclusión

PLANAZO aplica los principios de la programación orientada a objetos en un sistema organizado para gestionar eventos y reservas, calcular precios según el tipo de evento y controlar la disponibilidad de cupos.
