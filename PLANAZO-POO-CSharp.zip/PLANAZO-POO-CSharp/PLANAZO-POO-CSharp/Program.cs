using PLANAZO.Modelos;
using PLANAZO.Servicios;

namespace PLANAZO;

internal static class Program
{
    private static readonly GestorReservas Gestor = new();

    private static void Main()
    {
        CargarDatosIniciales();
        bool salir = false;

        while (!salir)
        {
            Console.Clear();
            MostrarEncabezado();
            Console.WriteLine("1. Ver eventos disponibles");
            Console.WriteLine("2. Consultar evento");
            Console.WriteLine("3. Reservar entradas");
            Console.WriteLine("4. Ver reservas realizadas");
            Console.WriteLine("5. Cancelar una reserva");
            Console.WriteLine("6. Ver resumen de reservas");
            Console.WriteLine("7. Consultar reservas por usuario");
            Console.WriteLine("0. Salir");
            Console.Write("\nSeleccione una opción: ");

            string? opcion = Console.ReadLine()?.Trim();
            Console.WriteLine();

            try
            {
                switch (opcion)
                {
                    case "1": VerEventos(); break;
                    case "2": ConsultarEvento(); break;
                    case "3": ReservarEntradas(); break;
                    case "4": VerReservas(); break;
                    case "5": CancelarReserva(); break;
                    case "6": VerResumen(); break;
                    case "7": ConsultarReservasUsuario(); break;
                    case "0": salir = true; Console.WriteLine("¡Gracias por usar PLANAZO!"); break;
                    default: Console.WriteLine("Opción no válida. Seleccione una opción del menú."); break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"No fue posible completar la operación: {ex.Message}");
            }

            if (!salir)
            {
                Console.WriteLine("\nPresione una tecla para continuar...");
                Console.ReadKey();
            }
        }
    }

    private static void CargarDatosIniciales()
    {
        Gestor.RegistrarEvento(new Cine(1, "Aventura en el espacio", DateTime.Today.AddDays(7), 18000m, 80));
        Gestor.RegistrarEvento(new Cine(2, "Misterio en la ciudad", DateTime.Today.AddDays(10), 22000m, 60));
        Gestor.RegistrarEvento(new Concierto(3, "Noche de Rock", DateTime.Today.AddDays(14), 50000m, 150));
        Gestor.RegistrarEvento(new Concierto(4, "Festival de Música", DateTime.Today.AddDays(21), 75000m, 200));
        Gestor.RegistrarEvento(new Taller(5, "Taller de fotografía", DateTime.Today.AddDays(5), 40000m, 25));
        Gestor.RegistrarEvento(new Taller(6, "Taller de pintura", DateTime.Today.AddDays(12), 35000m, 20));
    }

    private static void MostrarEncabezado()
    {
        Console.WriteLine("========================================");
        Console.WriteLine("          PLANAZO - EVENTOS");
        Console.WriteLine("========================================\n");
    }

    private static void VerEventos()
    {
        Console.WriteLine("EVENTOS DISPONIBLES");
        Console.WriteLine(new string('-', 90));
        foreach (Evento evento in Gestor.ObtenerEventos())
        {
            Console.WriteLine(evento);
        }
    }

    private static void ConsultarEvento()
    {
        int id = LeerEntero("Ingrese el identificador del evento: ");
        Evento evento = Gestor.ConsultarEvento(id);
        Console.WriteLine("\nDETALLE DEL EVENTO");
        Console.WriteLine($"Identificador : {evento.Id}");
        Console.WriteLine($"Nombre        : {evento.Nombre}");
        Console.WriteLine($"Tipo          : {evento.Tipo}");
        Console.WriteLine($"Fecha         : {evento.Fecha:dd/MM/yyyy}");
        Console.WriteLine($"Precio base   : {evento.PrecioBase:C}");
        Console.WriteLine($"Precio final  : {evento.CalcularPrecioFinal():C}");
        Console.WriteLine($"Capacidad     : {evento.CapacidadMaxima}");
        Console.WriteLine($"Cupos libres  : {evento.CuposDisponibles}");
    }

    private static void ReservarEntradas()
    {
        Console.Write("Nombre completo de la persona: ");
        string nombre = LeerTextoNoVacio();
        Usuario usuario = Gestor.ObtenerOCrearUsuario(nombre);

        int idEvento = LeerEntero("Identificador del evento: ");
        int cantidad = LeerEntero("Cantidad de entradas: ");
        Reserva reserva = Gestor.CrearReserva(usuario.Id, idEvento, cantidad);

        Console.WriteLine("\n¡Reserva realizada correctamente!");
        Console.WriteLine($"Código de reserva: {reserva.Id}");
        Console.WriteLine($"Persona          : {reserva.Usuario.Nombre}");
        Console.WriteLine($"Evento            : {reserva.Evento.Nombre}");
        Console.WriteLine($"Entradas          : {reserva.CantidadEntradas}");
        Console.WriteLine($"Valor total       : {reserva.ValorTotal:C}");
        Console.WriteLine($"Estado            : {reserva.Estado}");
    }

    private static void VerReservas()
    {
        IReadOnlyList<Reserva> reservas = Gestor.ObtenerReservas();
        if (reservas.Count == 0)
        {
            Console.WriteLine("Todavía no se han realizado reservas.");
            return;
        }

        Console.WriteLine("RESERVAS");
        Console.WriteLine(new string('-', 90));
        foreach (Reserva reserva in reservas)
        {
            Console.WriteLine(reserva);
        }
    }

    private static void CancelarReserva()
    {
        int id = LeerEntero("Identificador de la reserva que desea cancelar: ");
        Gestor.CancelarReserva(id);
        Console.WriteLine("La reserva fue cancelada y los cupos se devolvieron al evento.");
    }

    private static void VerResumen()
    {
        ResumenReservas resumen = Gestor.ObtenerResumen();
        Console.WriteLine("RESUMEN DE RESERVAS ACTIVAS");
        Console.WriteLine($"Reservas activas : {resumen.ReservasActivas}");
        Console.WriteLine($"Entradas reservadas: {resumen.EntradasReservadas}");
        Console.WriteLine($"Valor total      : {resumen.ValorTotal:C}");
    }

    private static void ConsultarReservasUsuario()
    {
        Console.Write("Nombre de la persona: ");
        string nombre = LeerTextoNoVacio();
        IReadOnlyList<Reserva> reservas = Gestor.ObtenerReservasPorUsuario(nombre);

        if (reservas.Count == 0)
        {
            Console.WriteLine("No se encontraron reservas para esa persona.");
            return;
        }

        foreach (Reserva reserva in reservas)
            Console.WriteLine(reserva);
    }

    private static int LeerEntero(string mensaje)
    {
        while (true)
        {
            Console.Write(mensaje);
            if (int.TryParse(Console.ReadLine(), out int valor))
                return valor;

            Console.WriteLine("Entrada incorrecta. Ingrese un número entero.");
        }
    }

    private static string LeerTextoNoVacio()
    {
        while (true)
        {
            string? valor = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(valor))
                return valor.Trim();

            Console.Write("El valor no puede estar vacío. Inténtelo de nuevo: ");
        }
    }
}
